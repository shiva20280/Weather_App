import pandas as pd 

df = pd.read_csv('weather.csv')


a=df['Temperature'].max()
print("Max Temperature :", a)
b=df['Temperature'].min()
print("Minimum temperature: ",b)
c=df['precipitation'].sum()
print(c, "in cm")